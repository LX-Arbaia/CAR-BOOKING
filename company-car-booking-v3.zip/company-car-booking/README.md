Company Car Booking App
=======================

This is a starter project (React + Tailwind + Firebase) for a company car booking system.

Important notes:
- Replace Firebase config in src/firebase.js.
- Deploy functions: firebase deploy --only functions
- To create the default admin user, call the HTTPS function createDefaultAdmin once (after deploying functions).
- Email sending requires setting functions config for mail (SMTP/SendGrid).

Admin credentials (pre-seeded via function):
- Email: sayed.shazly@lxpantos.com
- Password: Pantos@2025

