import { useEffect, useState, createContext, useContext } from 'react'
import { onAuthStateChanged } from 'firebase/auth'
import { auth, db } from '../firebase'
import { doc, getDoc } from 'firebase/firestore'

const AuthContext = createContext()

export function AuthProvider({ children }){
  const authHook = useProvideAuth();
  return <AuthContext.Provider value={authHook}>{children}</AuthContext.Provider>
}

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  return ctx || { user: null, loading: false };
}

function useProvideAuth(){
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(()=>{
    const unsub = onAuthStateChanged(auth, async (u) =>{
      if (!u){ setUser(null); setLoading(false); return }
      const userDoc = await getDoc(doc(db,'users',u.uid))
      const profile = userDoc.exists() ? userDoc.data() : { name: u.email, email: u.email, role: 'employee' }
      setUser({ uid: u.uid, email: u.email, ...profile })
      setLoading(false)
    })
    return ()=>unsub()
  },[])

  return { user, loading }
}
