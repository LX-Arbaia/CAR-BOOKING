import React, { useState } from 'react'
import { auth, db } from '../firebase'
import { createUserWithEmailAndPassword, signInWithEmailAndPassword } from 'firebase/auth'
import { doc, setDoc } from 'firebase/firestore'

export default function Login(){
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [mode, setMode] = useState('signin')
  const [error, setError] = useState(null)

  const handleSubmit = async (e)=>{
    e.preventDefault()
    setError(null)
    try{
      if (mode === 'signup'){
        const userCred = await createUserWithEmailAndPassword(auth,email,password)
        await setDoc(doc(db,'users',userCred.user.uid), { name: email.split('@')[0], email, role: 'employee' })
      } else {
        await signInWithEmailAndPassword(auth,email,password)
      }
    }catch(err){ setError(err.message) }
  }

  return (
    <div className="max-w-md mx-auto mt-12 bg-white p-6 rounded shadow">
      <h2 className="text-xl font-semibold mb-4">{mode === 'signup' ? 'Create account' : 'Sign in'}</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <input required value={email} onChange={e=>setEmail(e.target.value)} placeholder="email" className="w-full p-2 border rounded" />
        <input required value={password} onChange={e=>setPassword(e.target.value)} placeholder="password" type="password" className="w-full p-2 border rounded" />
        {error && <div className="text-red-600">{error}</div>}
        <div className="flex gap-2">
          <button type="submit" className="px-4 py-2 bg-blue-600 text-white rounded">{mode === 'signup'? 'Sign up':'Sign in'}</button>
          <button type="button" onClick={()=>setMode(mode==='signup'?'signin':'signup')} className="px-4 py-2 border rounded">Switch</button>
        </div>
      </form>
    </div>
  )
}
