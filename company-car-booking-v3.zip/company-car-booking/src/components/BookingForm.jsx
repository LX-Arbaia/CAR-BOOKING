import React, { useState } from 'react'
import { addDoc, collection, getDocs, query, where } from 'firebase/firestore'
import { db } from '../firebase'
import { auth } from '../firebase'

export default function BookingForm({ car }){
  const [startTime, setStartTime] = useState('')
  const [endTime, setEndTime] = useState('')
  const [reason, setReason] = useState('')
  const [message, setMessage] = useState(null)

  const handleSubmit = async (e)=>{
    e.preventDefault();
    setMessage(null);
    const user = auth.currentUser;
    if (!user) return setMessage('Sign in first.');

    const start = new Date(startTime);
    const end = new Date(endTime);
    if (end <= start) return setMessage('End time must be after start time.');

    // check overlap
    const q = query(collection(db,'bookings'), where('carId','==',car.id));
    const snapshot = await getDocs(q);
    const overlapping = snapshot.docs.some(doc => {
      const b = doc.data();
      const existingStart = new Date(b.startTime);
      const existingEnd = new Date(b.endTime);
      return (start < existingEnd && end > existingStart && b.status !== 'rejected');
    });

    if (overlapping) return setMessage('Car already booked for that time.');

    try{
      await addDoc(collection(db,'bookings'), {
        carId: car.id,
        carName: car.name,
        userId: user.uid,
        userEmail: user.email,
        startTime,
        endTime,
        reason,
        status: 'pending',
        createdAt: new Date().toISOString()
      });
      setMessage('Booking submitted successfully.');
      setStartTime(''); setEndTime(''); setReason('');
    }catch(err){ setMessage(err.message); }
  };

  return (
    <form onSubmit={handleSubmit} className="mt-3 space-y-2">
      <input type="datetime-local" required value={startTime} onChange={e=>setStartTime(e.target.value)} className="w-full border p-2 rounded" />
      <input type="datetime-local" required value={endTime} onChange={e=>setEndTime(e.target.value)} className="w-full border p-2 rounded" />
      <input placeholder="Reason" value={reason} onChange={e=>setReason(e.target.value)} className="w-full border p-2 rounded" />
      <button className="px-4 py-2 bg-green-600 text-white rounded">Book</button>
      {message && <div className="text-sm text-gray-700">{message}</div>}
    </form>
  );
}
