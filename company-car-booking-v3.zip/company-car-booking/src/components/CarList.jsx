import React, { useEffect, useState } from 'react'
import { collection, onSnapshot, query, orderBy } from 'firebase/firestore'
import { db } from '../firebase'
import BookingForm from './BookingForm'
import CalendarView from './CalendarView'

export default function CarList(){
  const [cars, setCars] = useState([])

  useEffect(()=>{
    const q = query(collection(db,'cars'), orderBy('name'))
    const unsub = onSnapshot(q, snap=>{
      setCars(snap.docs.map(d=>({ id: d.id, ...d.data() })))
    })
    return ()=>unsub()
  },[])

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <div>
        {cars.map(car=> (
          <div key={car.id} className="bg-white p-4 rounded shadow mb-4">
            <h3 className="font-semibold">{car.name} — {car.plate}</h3>
            <p className="text-sm">Status: {car.status || 'available'}</p>
            <BookingForm car={car} />
          </div>
        ))}
      </div>
      <div>
        <CalendarView />
      </div>
    </div>
  )
}
