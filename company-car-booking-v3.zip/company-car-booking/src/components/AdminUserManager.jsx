import React, { useState } from 'react';
import { httpsCallable } from 'firebase/functions';
import { functions } from '../firebase';

export default function AdminUserManager(){
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('employee');
  const [message, setMessage] = useState('');

  const createUser = async()=>{
    const fn = httpsCallable(functions, 'createUserByAdmin');
    await fn({ email, password, role });
    setMessage('User created successfully');
  };

  const resetPassword = async()=>{
    const fn = httpsCallable(functions, 'resetPasswordByAdmin');
    await fn({ email, newPassword: password });
    setMessage('Password reset successfully');
  };

  return (
    <div className="bg-white p-4 rounded shadow mt-6">
      <h3 className="text-lg font-semibold mb-2">Manage Users</h3>
      <input placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} className="border p-2 w-full mb-2" />
      <input placeholder="Password" value={password} onChange={e=>setPassword(e.target.value)} className="border p-2 w-full mb-2" />
      <select value={role} onChange={e=>setRole(e.target.value)} className="border p-2 w-full mb-2">
        <option value="employee">Employee</option>
        <option value="admin">Admin</option>
      </select>
      <div className="flex gap-2">
        <button onClick={createUser} className="px-3 py-1 bg-blue-600 text-white rounded">Create User</button>
        <button onClick={resetPassword} className="px-3 py-1 bg-yellow-600 text-white rounded">Reset Password</button>
      </div>
      {message && <div className="text-sm mt-2">{message}</div>}
    </div>
  );
}
