import React, { useEffect, useState } from 'react'
import { collection, onSnapshot, query, doc, updateDoc } from 'firebase/firestore'
import { db } from '../firebase'
import AdminUserManager from './AdminUserManager'

export default function AdminDashboard(){
  const [bookings, setBookings] = useState([])

  useEffect(()=>{
    const q = query(collection(db,'bookings'))
    const unsub = onSnapshot(q, snap=> setBookings(snap.docs.map(d=>({ id: d.id, ...d.data() }))))
    return ()=>unsub()
  },[])

  const setStatus = async (id, status) =>{
    await updateDoc(doc(db,'bookings',id), { status })
  }

  return (
    <div>
      <h2 className="text-xl mb-4">Admin Dashboard</h2>
      <AdminUserManager />
      <div className="space-y-4 mt-6">
        {bookings.map(b=> (
          <div key={b.id} className="bg-white p-4 rounded shadow">
            <div className="flex justify-between items-center">
              <div>
                <div className="font-semibold">{b.carName} — {b.userEmail}</div>
                <div className="text-sm">{b.startTime} → {b.endTime}</div>
                <div className="text-sm">{b.reason}</div>
                <div className="text-sm">Status: {b.status}</div>
              </div>
              <div className="flex gap-2">
                <button onClick={()=>setStatus(b.id,'approved')} className="px-3 py-1 bg-green-600 text-white rounded">Approve</button>
                <button onClick={()=>setStatus(b.id,'rejected')} className="px-3 py-1 bg-red-600 text-white rounded">Reject</button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
