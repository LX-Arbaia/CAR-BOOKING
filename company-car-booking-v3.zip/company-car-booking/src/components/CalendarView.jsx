import React, { useEffect, useState } from 'react';
import { Calendar, momentLocalizer } from 'react-big-calendar';
import moment from 'moment';
import 'react-big-calendar/lib/css/react-big-calendar.css';
import { collection, onSnapshot } from 'firebase/firestore';
import { db } from '../firebase';

const localizer = momentLocalizer(moment);

export default function CalendarView(){
  const [events, setEvents] = useState([]);

  useEffect(()=>{
    const unsub = onSnapshot(collection(db,'bookings'), snap => {
      setEvents(snap.docs.map(d=>{
        const b = d.data();
        return {
          id: d.id,
          title: `${b.carName} (${b.status})`,
          start: new Date(b.startTime),
          end: new Date(b.endTime),
          allDay: false
        }
      }));
    });
    return ()=>unsub();
  },[]);

  return (
    <div className="p-4 bg-white rounded shadow">
      <h3 className="text-lg font-semibold mb-2">Booking Calendar</h3>
      <Calendar
        localizer={localizer}
        events={events}
        startAccessor="start"
        endAccessor="end"
        style={{ height: 500 }}
      />
    </div>
  );
}
