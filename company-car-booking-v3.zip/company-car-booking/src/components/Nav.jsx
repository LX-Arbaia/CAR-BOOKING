import React from 'react'
import { signOut } from 'firebase/auth'
import { auth } from '../firebase'
import { Link } from 'react-router-dom'

export default function Nav({ user }){
  return (
    <nav className="bg-white shadow">
      <div className="max-w-6xl mx-auto p-4 flex justify-between items-center">
        <div className="font-bold">Company Car Booking</div>
        <div className="flex gap-4 items-center">
          <Link to="/">Home</Link>
          {user && user.role === 'admin' && <Link to="/admin">Admin</Link>}
          {user ? (
            <div className="flex items-center gap-2">
              <span>{user.name || user.email}</span>
              <button onClick={()=>signOut(auth)} className="px-3 py-1 border rounded">Sign out</button>
            </div>
          ) : <Link to="/">Sign in</Link>}
        </div>
      </div>
    </nav>
  )
}
